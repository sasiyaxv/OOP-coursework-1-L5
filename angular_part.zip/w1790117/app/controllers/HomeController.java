package controllers;

import CLI.*;
import com.fasterxml.jackson.databind.JsonNode;
import play.libs.Json;
import play.mvc.*;

import java.io.*;
import java.util.*;


public class HomeController extends Controller {

    Random rand = new Random();
    PremierLeagueManager premierLeagueManager = new PremierLeagueManager();

    private static ArrayList readClubFromFile = new ArrayList();
    private static ArrayList readMatchesFromFile = new ArrayList();

    private static ArrayList readClubs = new ArrayList();
    private static ArrayList readMatches = new ArrayList();


    // get clubs
    public ArrayList<FootballClub> getFootballClubs() {

        try (
                FileInputStream fileInputStream = new FileInputStream("footballClubDetails.txt");
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

        ) {
            readClubFromFile = (ArrayList) objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return readClubFromFile;
    }

    //get matches
    public ArrayList<Match> getMatches() {

        try (
                FileInputStream fileInputStream = new FileInputStream("matchDetails.txt");
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

        ) {
            readMatchesFromFile = (ArrayList) objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return readMatchesFromFile;
    }

    //-------------------------------Sorting options in the clubs table-----------------------------------------
    public Result sortToPoints() {

        getFootballClubs();
        Collections.sort(HomeController.readClubFromFile, new PointsComparator());

        JsonNode jsonNode = Json.toJson(HomeController.readClubFromFile);
        return ok(jsonNode).as("application/json");
    }

    public Result sortToGoals() {

        getFootballClubs();
//        accepts two parameters , a arraylist and comparator
        Collections.sort(HomeController.readClubFromFile, new GoalsComparator());

        JsonNode jsonNode = Json.toJson(readClubFromFile);
        return ok(jsonNode).as("application/json");
    }

    public Result sortToWins() {

        getFootballClubs();
        Collections.sort(HomeController.readClubFromFile, new WinsComparator());

        JsonNode jsonNode = Json.toJson(readClubFromFile);
        return ok(jsonNode).as("application/json");
    }

//--------------------------------------------------------------------------------------------------------------


//-------------------------------Sorting options in the match table-----------------------------------------

    public Result sortToDate() {
        getMatches();

        Collections.sort(HomeController.readMatchesFromFile, new DateComparator());

        JsonNode jsonNode = Json.toJson(readMatchesFromFile);
        return ok(jsonNode).as("application/json");
    }

    //--------------------------------------------------------------------------------------------------------------
//    generating a random match
    public Result generateMatch() {

        // generating random numbers
        // note : random numbers int rand = 10 + random.nextInt(20); (this will give a value between 10 and 30)
        int teamOne = 0;
        int teamTwo = 0;
        int teamOneGoals = rand.nextInt(20);
        int teamTwoGoals = rand.nextInt(20);
        int year = 1900 + rand.nextInt(200);
        int month = 1 + rand.nextInt(12);
        int day = 1 + rand.nextInt(31);

        try (
                FileInputStream fileInputStream = new FileInputStream("footballClubDetails.txt");
                ObjectInputStream objectinputstream = new ObjectInputStream(fileInputStream);
        ) {
            List clubData = (List) objectinputstream.readObject();

//                checking if the team one and two are same and getting team names again and again until they are not equal
            boolean flag = true;
            while (flag) {
                teamOne = rand.nextInt(clubData.size());
                teamTwo = rand.nextInt(clubData.size());
                if (teamOne != teamTwo) {
                    flag = false;
                }
            }

            FootballClub footballClub1 = (FootballClub) clubData.get(teamOne);
            FootballClub footballClub2 = (FootballClub) clubData.get(teamTwo);

            DateTime dateTime = new DateTime(year, month, day);
            readMatches.add(new Match(footballClub1.getRegNo(), footballClub2.getRegNo(), teamOneGoals, teamTwoGoals, dateTime));
            premierLeagueManager.addPlayedMatch(new Match(footballClub1.getRegNo(), footballClub2.getRegNo(), teamOneGoals, teamTwoGoals, dateTime));

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

//        saving the generated match to match file
        try (
                FileOutputStream fileOutputStream = new FileOutputStream("matchDetails.txt");
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        ) {
            objectOutputStream.writeObject(readMatches);

        } catch (Exception e) {
            e.printStackTrace();
        }
        JsonNode jsonNode = Json.toJson(readMatches);
        return ok(jsonNode).as("application/json");
    }

    //    this method will return read clubs
    public Result readFileClubs() {
        try (
                FileInputStream fileInputStream = new FileInputStream("footballClubDetails.txt");
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        ) {
            readClubs = (ArrayList) objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        JsonNode jsonNode = Json.toJson(readClubs);
        return ok(jsonNode).as("application/json");
    }

    public Result readMatches() {
        try (
                FileInputStream fileInputStream = new FileInputStream("matchDetails.txt");
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        ) {
            readMatches = (ArrayList) objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        JsonNode jsonNode = Json.toJson(readMatches);
        return ok(jsonNode).as("application/json");
    }

    //    method to search day in matches
    public Result postSearchedValue(int searchedText) {

        ArrayList<Match> searchedArrayList = new ArrayList<>();
//        searching for matching records
        for (Match match : getMatches()) {
            if (match.getMatchDate().getDay() == searchedText) {
                searchedArrayList.add(match);
            }
        }

        JsonNode jsonNode = Json.toJson(searchedArrayList);
        return ok(jsonNode).as("application/json");
    }
}
