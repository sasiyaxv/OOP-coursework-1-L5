package CLI;

import java.util.Comparator;

//comparator to sort out matches according to date
// used in GUI
public class DateComparator implements Comparator<Match> {

    public int compare(Match match1, Match match2) {

//        sorting according to year first
        if (match1.getMatchDate().getYear() < match2.getMatchDate().getYear()) {
            return -1;
        } else if (match1.getMatchDate().getYear() > match2.getMatchDate().getYear()) {
            return 1;
//            if the year is equal sorting according to month
        } else if (match1.getMatchDate().getYear() == match2.getMatchDate().getYear()) {
            if (match1.getMatchDate().getMonth() < match2.getMatchDate().getMonth()) {
                return -1;
            } else if (match1.getMatchDate().getMonth() > match2.getMatchDate().getMonth()) {
                return 1;
//     if the month is equal sorting according to date played
            } else if (match1.getMatchDate().getMonth() == match2.getMatchDate().getMonth()) {
                if (match1.getMatchDate().getDay() < match2.getMatchDate().getDay()) {
                    return -1;
                } else if (match1.getMatchDate().getDay() > match2.getMatchDate().getDay()) {
                    return 1;
                }
            }
        }
        return 0;
    }

}
