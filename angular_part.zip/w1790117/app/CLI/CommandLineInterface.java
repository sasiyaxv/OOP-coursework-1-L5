package CLI;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CommandLineInterface {

    private static List readClubs = new ArrayList();
    private static List readMatches = new ArrayList();
    private static int counter = 0;

    public static void main(String[] args) {
        File file = new File("footballClubDetails.txt");
        File file2 = new File("matchDetails.txt");
        if (file.length()==0){
            System.out.println("No save data was found in the save file. ");
        }else {
            try {
                FileInputStream fileInputStream = new FileInputStream(file);
                FileInputStream fileInputStream1 = new FileInputStream(file2);
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                ObjectInputStream objectInputStream1 = new ObjectInputStream(fileInputStream1);

                Object matchArray = objectInputStream1.readObject();
                readMatches = (ArrayList<Match>) matchArray;

                Object footballClubArray = objectInputStream.readObject();
                readClubs = (ArrayList<FootballClub>) footballClubArray;
                System.out.println(readClubs);
                System.out.println(readMatches);
            } catch (IOException | ClassNotFoundException e) {
                System.out.println("Exception!!");
            }
        }
        Main main = new Main();
        main.mainMenu();
    }

//    method to return the football club counter
    public int getCurrentValue(){return counter;  }
//    methods to return the football club methods
    public List<FootballClub> getClubs() {
        return readClubs;
    }
    public List<Match> getMatches() {
        return readMatches;
    }
}
