package CLI;

import java.util.Comparator;

//comparator to sort out Points
// used in GUI
public class PointsComparator implements Comparator<FootballClub> {

    public int compare(FootballClub footballClub1, FootballClub footballClub2) {
        if (footballClub1.getNoOfPoints() > footballClub2.getNoOfPoints()) {
            return -1;
        } else if (footballClub1.getNoOfPoints() < footballClub2.getNoOfPoints()) {
            return 1;
        } else {
            return 0;
        }
    }
}
