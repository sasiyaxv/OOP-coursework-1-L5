package CLI;

//school and university football club classes are implemented for future implementation purposes which is mentioned in the specification sheet
public class UniversityFootballClub extends FootballClub {

    private String universityName;

    public UniversityFootballClub() {
    }

    public UniversityFootballClub(String universityName) {
        this.universityName = universityName;
    }

    public String getUniversityName() {
        return universityName;
    }

    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }

    @Override
    public String toString() {
        return "UniversityFootballClub{" + super.toString() +
                "universityName='" + universityName + '\'' +
                "} ";
    }
}
