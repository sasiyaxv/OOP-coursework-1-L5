package CLI;

import java.io.IOException;
import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Scanner;

/*Student ID - 2019586
UOW ID - w1790117
Name - S.I. Withanage
* "I confirm that I understand what plagiarism /
collusion/contract cheating is and have read and
understood the section on Assessment Offences in the
Essential Information for Students. The work that I
have submitted is entirely my own. Any work from
other authors is duly referenced and acknowledged.
*
* */

public class Main implements Serializable {

    PremierLeagueManager premierLeagueManager = new PremierLeagueManager();
    CommandLineInterface commandLineInterface = new CommandLineInterface();
    DateTime dateTime = new DateTime();

    Scanner scanner = new Scanner(System.in);
    Scanner scannerTwo = new Scanner(System.in);


    //main menu of the implementation. Menu is divided into two parts.
    public void mainMenu() {
        System.out.println("==== Welcome to Premiere League Manager ====\n");
        System.out.println("Please note that using this manager you can add, delete or view data of a football club.\nAdded data also can be saved to a file. Begin by selecting your option below.\n");

        int userChoice;
        while (true) {
            try {
                System.out.println("1. Add football club. ");
                System.out.println("2. Delete football club. ");
                System.out.println("3. View football club. ");
                System.out.println("4. Display premiere league table.");
                System.out.println("5. Add played match. ");
                System.out.println("6. Quit. ");
                System.out.print("Enter option : ");

                userChoice = Integer.parseInt(scanner.next());

                //users first option will be passed to submenu method
                subMenu(userChoice);
                break;
            } catch (NumberFormatException | IOException e) {
                System.out.println("Number format exception occurred.");
            }
        }
    }

    public void subMenu(int userChoice) throws IOException {

        switch (userChoice) {
            //user selects add football club option. extracting information
            case 1: {

                System.out.print("Club registration number : ");
                String clubRegNo = scanner.next();

                System.out.print("Club name : ");
                String clubName = scannerTwo.next();

                System.out.print("Club location : ");
                String clubLocation = scanner.next();

                System.out.println("Enter created date details.");


                try {
                    System.out.println("Year : ");
                    int year = scannerTwo.nextInt();
                    dateTime.setYear(year);

                    System.out.println("Month : ");
                    int month = scanner.nextInt();
                    dateTime.setMonth(month);

                    System.out.println("Day : ");
                    int day = scannerTwo.nextInt();
                    dateTime.setDay(day);

                    System.out.print("Club contact no : ");
                    int contactNo = scanner.nextInt();

                    System.out.print("Matched played  : ");
                    int matchesPlayed = scannerTwo.nextInt();

                    System.out.print("Matched won  : ");
                    int matchesWin = scanner.nextInt();

                    System.out.print("Matched draw  : ");
                    int matchesDraw = scannerTwo.nextInt();

                    System.out.print("Matched lost  : ");
                    int matchesLost = scanner.nextInt();

                    System.out.print("No of goals received  : ");
                    int noOfGoalsReceived = scannerTwo.nextInt();

                    System.out.print("No of goals scored : ");
                    int noOfGoalsScored = scanner.nextInt();

                    System.out.print("No of points : ");
                    int noOfPoints = scannerTwo.nextInt();

                    premierLeagueManager.addFootballClub(new FootballClub(clubRegNo, clubName, clubLocation, new DateTime(year, month, day), contactNo, matchesWin, matchesDraw, matchesLost, noOfGoalsReceived, noOfGoalsScored, noOfPoints, matchesPlayed));
                    mainMenu();
                    break;

                }catch (InputMismatchException e)
                {
                    System.out.println("Invalid Input. Exception occurred.");
                }
            }


            case 2: {
                System.out.print("Enter the registration no of club you want to delete : ");
                String removeClub = scannerTwo.next();
                premierLeagueManager.deleteFootballClub(removeClub);
                mainMenu();
                break;
            }
            //viewing a football club option
            case 3: {
                System.out.print("Enter the name of club you want to view : ");
                String regNo = scanner.next();
                premierLeagueManager.viewClubData(regNo);
                mainMenu();
                break;
            }
            //displaying premiere league table
            case 4: {
                premierLeagueManager.displayPremiereLeagueTable();
                mainMenu();
                break;
            }
            //adding a played match
            case 5: {
                System.out.println("Enter the played match details below.");
                System.out.print("Team one register number :  ");
                String teamOneReg = scanner.next();
                System.out.print("Team two register number :  ");
                String teamTwoReg = scannerTwo.next();
                System.out.print("Team one Goals :  ");
                int teamOneGoals = scanner.nextInt();
                System.out.print("Team Two Goals :  ");
                int teamTwoGoals = scannerTwo.nextInt();
                System.out.println("Enter match date/time details below.");

                System.out.println("Year : ");
                int year = scannerTwo.nextInt();
                dateTime.setYear(year);

                System.out.println("Month : ");
                int month = scanner.nextInt();
                dateTime.setMonth(month);

                System.out.println("Day : ");
                int day = scannerTwo.nextInt();
                dateTime.setDay(day);

                System.out.println("Hour : ");
                int hour = scanner.nextInt();
                dateTime.setHour(hour);

                System.out.println("Minute : ");
                int minute = scannerTwo.nextInt();
                dateTime.setMinute(minute);

                premierLeagueManager.addPlayedMatch(new Match(teamOneReg, teamTwoReg, teamOneGoals, teamTwoGoals, new DateTime(year, month, day, hour, minute)));
                //adding data to the list to save
                commandLineInterface.getMatches().add((new Match(teamOneReg, teamTwoReg, teamOneGoals, teamTwoGoals, new DateTime(year, month, day, hour, minute))));
                System.out.println("Played match has been added successfully.");
                mainMenu();
                break;
            }
            //quit PLM
            case 6: {
                System.out.println("---- Are you sure you want to exit ('y','n') ----");
                System.out.print("Exit : ");
                String confirmExit = scannerTwo.next();
                confirmExit = confirmExit.toLowerCase();

                if (confirmExit.equals("y")) {
                    //writing match data to a file
                    premierLeagueManager.saveDetailsToFile();
                    System.out.println("All data has been written to a file successfully.");
                    System.exit(0);
                } else {
                    mainMenu();
                }

                break;
            }
            default:
                System.out.println("Invalid choice. Please enter again.");
                break;
        }
    }

}



