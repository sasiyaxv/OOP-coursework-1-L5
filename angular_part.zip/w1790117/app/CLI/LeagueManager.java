package CLI;

//Interface for Premiere League Manager
public interface LeagueManager {

    void addFootballClub(FootballClub footballClub);

    void deleteFootballClub(String regNo);

    void viewClubData(String regNo);

    void displayPremiereLeagueTable();

    void addPlayedMatch(Match playedMatch);
}
