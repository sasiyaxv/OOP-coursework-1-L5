package CLI;

import java.io.Serializable;

//this class implements serializable and comparable
public class FootballClub  extends SportsClub implements Comparable<FootballClub>,Serializable{

    private int matchesWin;
    private int matchesDraw;
    private int matchesLost;
    private int noOfGoalsReceived;
    private int noOfGoalsScored;
    private int noOfPoints;
    private int matchesPlayed;

    public FootballClub(){
        super();

    }

    public FootballClub(String regNo, String nameOfClub, String locationOfClub, DateTime dateCreated, int contactNo, int matchesWin, int matchesDraw, int matchesLost, int noOfGoalsReceived, int noOfGoalsScored, int noOfPoints, int matchesPlayed) {
        super(regNo, nameOfClub, locationOfClub, dateCreated, contactNo);
        this.matchesWin = matchesWin;
        this.matchesDraw = matchesDraw;
        this.matchesLost = matchesLost;
        this.noOfGoalsReceived = noOfGoalsReceived;
        this.noOfGoalsScored = noOfGoalsScored;
        this.noOfPoints = noOfPoints;
        this.matchesPlayed = matchesPlayed;
    }

    public int getMatchesWin() {
        return matchesWin;
    }

    public void setMatchesWin(int matchesWin) {
        if (matchesWin < 0 ){
            System.out.println("Matches cant be negative,");
            throw new IllegalArgumentException();
        }else {
            this.matchesWin = matchesWin;
        }
    }

    public int getMatchesDraw() {
        return matchesDraw;
    }

    public void setMatchesDraw(int matchesDraw) {

        if (matchesDraw < 0 ){
            System.out.println("Matches cant be negative,");
            throw new IllegalArgumentException();
        }else {
            this.matchesDraw = matchesDraw;
        }

    }

    public int getMatchesLost() {
        return matchesLost;
    }

    public void setMatchesLost(int matchesLost) {

        if (matchesLost < 0 ){
            System.out.println("Matches cant be negative,");
            throw new IllegalArgumentException();
        }else {
            this.matchesLost = matchesLost;

        }
    }

    public int getNoOfGoalsReceived() {
        return noOfGoalsReceived;
    }

    public void setNoOfGoalsReceived(int noOfGoalsReceived) {
        if (noOfGoalsReceived < 0 ){
            System.out.println("Goals cant be negative,");
            throw new IllegalArgumentException();
        }else {
            this.noOfGoalsReceived = noOfGoalsReceived;
        }
    }

    public int getNoOfGoalsScored() {
        return noOfGoalsScored;
    }

    public void setNoOfGoalsScored(int noOfGoalsScored) {

        if (noOfGoalsScored < 0 ){
            System.out.println("Goals cant be negative,");
            throw new IllegalArgumentException();
        }else {
            this.noOfGoalsScored = noOfGoalsScored;

        }
    }

    public int getNoOfPoints() {
        return noOfPoints;
    }

    public void setNoOfPoints(int noOfPoints) {

        if (noOfPoints < 0 ){
            System.out.println("Points cant be negative,");
            throw new IllegalArgumentException();
        }else {
            this.noOfPoints = noOfPoints;


        }

    }

    public int getMatchesPlayed() {
        return matchesPlayed;
    }

    public void setMatchesPlayed(int matchesPlayed) {

        if (matchesPlayed < 0 ){
            System.out.println("Matches cant be negative,");
            throw new IllegalArgumentException();
        }else {
            this.matchesPlayed = matchesPlayed;
        }

    }

//    compare used to order clubs and used in PLM .
//    First they will be ordered according to points. if two clubs have same points they will be sorted using goals scored
    @Override
    public int compareTo(FootballClub footballClub) {
        if (this.getNoOfPoints() > footballClub.getNoOfPoints())
        {
            return -1;
        }
        else if (this.getNoOfPoints() < footballClub.getNoOfPoints()){
            return 1;
        }
        else {
            if (this.getNoOfGoalsScored() > footballClub.getNoOfGoalsScored())
            {
                return -1;
            }
            else if (this.getNoOfGoalsScored() < footballClub.getNoOfGoalsScored()){
                return 1;
            }
        }
        return 0;
    }


    @Override
    public String toString() {
        return  "Footballclub { "+super.toString()+
                "matchesWin=" + matchesWin +
                ", matchesDraw=" + matchesDraw +
                ", matchesLost=" + matchesLost +
                ", noOfGoalsReceived=" + noOfGoalsReceived +
                ", noOfGoalsScored=" + noOfGoalsScored +
                ", noOfPoints=" + noOfPoints +
                ", matchesPlayed=" + matchesPlayed +
                "} " ;
    }
}
