package CLI;

import java.util.Comparator;

public class GoalsComparator implements Comparator<FootballClub> {

    public int compare(FootballClub footballClub1, FootballClub footballClub2) {
        if (footballClub1.getNoOfGoalsScored() > footballClub2.getNoOfGoalsScored()){
            return -1;
        }else if (footballClub1.getNoOfGoalsScored() < footballClub2.getNoOfGoalsScored()) {
            return 1;
        }else {
            return 0;
        }
    }
}
