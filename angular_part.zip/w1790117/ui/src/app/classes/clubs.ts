export class Clubs {
  regNo: string;
  nameOfClub: string;
  locationOfClub: string;
  dateCreated: {
    year: number;
    month: number;
    day: number;
    hour: number;
    minute: number;
  }
  contactNo: number;
  matchesWin: number;
  matchesDraw: number;
  matchesLost: number;
  noOfGoalsReceived: number;
  noOfGoalsScored: number;
  noOfPoints: number;
  matchesPlayed: number;
}
