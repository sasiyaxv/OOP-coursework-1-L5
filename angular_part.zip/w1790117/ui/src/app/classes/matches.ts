export class Matches {
  teamOne: string;
  teamTwo: string;
  teamOneGoals: number;
  teamTwoGoals: number;
  matchDate: {
    "year": number;
    "month": number;
    "day": number;
    "hour": number;
    "minute": number;
  }
}
