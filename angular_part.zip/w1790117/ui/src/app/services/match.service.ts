import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import {HttpClient} from "@angular/common/http";

@Injectable()
export class matchService {

private num;

  constructor(private httpClient:HttpClient) {
  }

  getRefresh() : Observable<any>{
    return this.httpClient.get("http://localhost:9000/api/matchread");
  }

  //this will return the matches
  getMatches(): Observable<any>{
    return  this.httpClient.get("http://localhost:9000/api/matchread");
  }
  // this will return the matches sorted to date
  getSortDate(): Observable<any>{
    return  this.httpClient.get("http://localhost:9000/api/sorttodate");

  }
  //to generate a new match
  getGenerate() : Observable<any>{
    return  this.httpClient.get("http://localhost:9000/api/generatedmatch");

  }
  // searching match
  getSearchedMatch(num): Observable<any>{
     this.num = num;
    return  this.httpClient.get("http://localhost:9000/api/searchedmatches/"+num);
  }

}
