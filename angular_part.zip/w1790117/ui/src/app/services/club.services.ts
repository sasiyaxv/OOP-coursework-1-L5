import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import {HttpClient} from "@angular/common/http";

@Injectable()
export class clubServices {

  constructor(private httpClient:HttpClient) {
  }
  //get clubs
  getClubs(): Observable<any>{
    return  this.httpClient.get("http://localhost:9000/api/clubread");
  }
  // get clubs sorted to points
  getSortPoints(): Observable<any> {
    return this.httpClient.get("http://localhost:9000/api/sorttopoints");
  }
  //get clubs sorted to wins
  getSortWins() : Observable<any>{
    return this.httpClient.get("http://localhost:9000/api/sorttowins");

  }
  //get clubs sorted to goals
  getSortGoals() : Observable<any>{
    return this.httpClient.get("http://localhost:9000/api/sorttogoals");
  }

}
