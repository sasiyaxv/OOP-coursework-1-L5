import { Component } from '@angular/core';
import {Clubs} from "./classes/clubs";

import {clubServices} from "./services/club.services";
import {matchService} from "./services/match.service";
import {Matches} from "./classes/matches";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private  _clubApiService : clubServices,private _matchApiService : matchService) {
  }

  listClubs : Clubs[];
  listMatches : Matches[];

  finalGeneratedMatch : Matches[] = [];

   searchedText : number;

  //method to sort to points
  public sortToPoints() : void{
    this._clubApiService.getSortPoints()
      .subscribe(
        data => {
          this.listClubs = data;
        }
      )
  }

  //service call to sort to wins
  public sortToWins() : void{
     this._clubApiService.getSortWins()
       .subscribe(
         data => {
           this.listClubs = data;
         }
       )
   }

  //service call to sort to goals
  public sortToGoals() : void{
    this._clubApiService.getSortGoals()
      .subscribe(
        data => {
          this.listClubs = data;
        }
      )
   }

  //service call sort to date(matches)
  public sortToDate() : void {
     this._matchApiService.getSortDate()
       .subscribe(
         data => {
           this.listMatches = data;
         }
       )
   }

  public generateMatch() : void{
    this._matchApiService.getGenerate()
      .subscribe(
        data => {
          this.listMatches=data;
           let last:any = this.listMatches[this.listMatches.length-1];
          this.finalGeneratedMatch.push(last);
        }
      )
   }
   public refreshLocation(): void{
    window.location.reload();
   }

   public searchedValue() : void{

    const searchedText = this.searchedText;
    //checking for invalid inputs
    if (searchedText == null || searchedText <= 0 || searchedText > 31){
      alert("Please enter a valid value."+ searchedText+ " is not a valid entry.");
    }
    else {
      this._matchApiService.getSearchedMatch(searchedText)
        .subscribe(
          data => {
            this.listMatches = data;
          }
        )
    }
   }

  // using nginit to iterate through clubs when loading arrays
  ngOnInit(){
    this._clubApiService.getClubs()
      .subscribe(
        data=>{
          this.listClubs = data;
        }
      )
    this._matchApiService.getMatches()
      .subscribe(
        data=>{
          this.listMatches = data;
        }
      )



  }
}
