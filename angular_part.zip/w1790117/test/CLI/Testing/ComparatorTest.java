package CLI.Testing;

import CLI.*;
import org.junit.Test;

import static junit.framework.TestCase.assertTrue;
import static junit.framework.TestCase.fail;

public class ComparatorTest {

    //    creating objects to test comparators
//    clearly the footballclub1 has more stats(wins,points than other one) . for testing purposes
    FootballClub footballClub = new FootballClub("SRS", "FDS", "LA", new DateTime(2000, 2, 22), 123456, 1, 1, 1, 1, 1, 1, 1);
    FootballClub footballClub1 = new FootballClub("SRS", "FDS", "LA", new DateTime(2000, 2, 22), 123456, 5, 5, 5, 5, 5, 5, 5);

    //    creating datetime objects to check date sorting comparator
    DateTime dateTime = new DateTime(2000, 2, 2);
    DateTime dateTime1 = new DateTime(2000, 2, 3);

    DateTime dateTime2 = new DateTime(2000, 2, 2);


    //sample matches to sort by comparator
    Match match = new Match("111", "1112", 1, 1, dateTime);
    Match match1 = new Match("111", "1113", 3, 3, dateTime1);


    // comparator testing--------------------------------------------------------
    @Test
    public void winsComparatorTest() {
//        when passe since footballclub1 has more wins it should return -1
        WinsComparator winsComparator = new WinsComparator();
        if (winsComparator.compare(footballClub1, footballClub) == -1) {
            assertTrue("Passed", winsComparator.compare(footballClub1, footballClub) == -1);
        } else {
            fail("Test failed.");
        }
    }

    @Test
    public void pointsComparatorTest() {
//        when passe since footballclub1 has more points it should return -1
        PointsComparator pointsComparator = new PointsComparator();
        if (pointsComparator.compare(footballClub1, footballClub) == -1) {
            assertTrue("Passed", pointsComparator.compare(footballClub1, footballClub) == -1);
        } else {
            fail("Test failed.");
        }
    }

    @Test
    public void goalsComparatorTest() {
//        when passe since footballclub1 has more goals it should return -1
        GoalsComparator goalsComparator = new GoalsComparator();
        if (goalsComparator.compare(footballClub1, footballClub) == -1) {
            assertTrue("Passed", goalsComparator.compare(footballClub1, footballClub) == -1);
        } else {
            fail("Test failed.");
        }
    }

    //    testing match sorting comparator
//    since the year and month are same comparator check for date. since the date is different by 1 day it will return 1.
    @Test
    public void dateTimeComparatorTest() {
        DateComparator dateComparator = new DateComparator();
        if (dateComparator.compare(match1, match) == 1) {
            assertTrue("Passed", dateComparator.compare(match1, match) == 1);
        } else {
            fail("Test failed.");
        }
    }
}