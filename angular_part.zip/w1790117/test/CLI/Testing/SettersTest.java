package CLI.Testing;

import CLI.DateTime;
import CLI.FootballClub;
import org.junit.Test;

public class SettersTest {

    //Date time class testing -----------------------------------------------------
    @Test(expected = IllegalArgumentException.class)
    public void dateTimeSetYearTest() {
        DateTime dateTime = new DateTime();
        dateTime.setYear(1700);
    }

    @Test(expected = IllegalArgumentException.class)
    public void dateTimeSetMonthTest() {
        DateTime dateTime = new DateTime();
        dateTime.setMonth(13);
    }

    @Test(expected = IllegalArgumentException.class)
    public void dateTimeSetDayTest() {
        DateTime dateTime = new DateTime();
        dateTime.setDay(-2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void dateTimeSetHourTest() {
        DateTime dateTime = new DateTime();
        dateTime.setHour(25);
    }

    @Test(expected = IllegalArgumentException.class)
    public void dateTimeSetMinuteTest() {
        DateTime dateTime = new DateTime();
        dateTime.setMinute(61);
    }
//----------------------------------------------------------------------------

//Football club class--------------------------------------------------------

    @Test(expected = IllegalArgumentException.class)
    public void footballClubWinsTest() {
        FootballClub footballClub = new FootballClub();
        footballClub.setMatchesWin(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void footballClubGoalsTest() {
        FootballClub footballClub = new FootballClub();
        footballClub.setNoOfGoalsScored(-2);
    }

// ---------------------------------------------------------------------------
}